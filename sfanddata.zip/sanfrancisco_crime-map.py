import pandas as pd 
import numpy as np
from sklearn.preprocessing import MinMaxScaler
from sklearn.cluster import KMeans
import plotly.express as px
import plotly

# Load the dataset
data = pd.read_csv("train.csv")

# Display the first few rows of the dataset
print("Initial Data Head:\n", data.head())

# Check for missing values
print("Missing Values:\n", data.isnull().sum())

# Print column names
print("Columns:\n", data.columns)

# Drop irrelevant columns
data = data.drop(["Descript", "DayOfWeek", "PdDistrict", "Resolution", "Address"], axis=1)
print("Data after Dropping Columns:\n", data.head())

# Extract year from the 'Dates' column
data["Dates"] = data["Dates"].str.split("-").str[0]
print("Data after Extracting Year:\n", data.head())

# Filter data for the year 2014
data2014 = data[data["Dates"] == "2014"]
print("Data for the Year 2014:\n", data2014.head())

# Normalize the 'X' and 'Y' columns
scaler = MinMaxScaler()
data2014["x_scaled"] = scaler.fit_transform(data2014[["X"]])
data2014["y_scaled"] = scaler.fit_transform(data2014[["Y"]])
print("Data2014 with Scaled X and Y:\n", data2014.head())

# Determine the optimal number of clusters
k_range = range(1, 15)
inertia_list = []

for k in k_range:
    model = KMeans(n_clusters=k)
    model.fit(data2014[["x_scaled", "y_scaled"]])
    inertia_list.append(model.inertia_)

# Plot the inertia values
import matplotlib.pyplot as plt

plt.xlabel("K")
plt.ylabel("Inertia")
plt.plot(k_range, inertia_list)
plt.title("Elbow Method for Optimal K")
plt.show()

# Fit the KMeans model with the optimal number of clusters (e.g., 5)
model = KMeans(n_clusters=5)
data2014["cluster"] = model.fit_predict(data2014[["x_scaled", "y_scaled"]])
print("Data2014 with Clusters:\n", data2014.head())

# Plot the clustered data on a map
figure = px.scatter_mapbox(
    data2014,
    lat="Y",
    lon="X",
    center=dict(lat=37.8, lon=-122.4),
    zoom=9,
    mapbox_style="stamen-terrain",
    color="cluster",
    title="Crime Map",
    width=1100,
    height=700,
    hover_data=["cluster", "Category", "Y", "X"]
)

# Show the figure
figure.show()

# Save the plot to an HTML file and open it
plotly.offline.plot(figure, filename="map.html", auto_open=True)

